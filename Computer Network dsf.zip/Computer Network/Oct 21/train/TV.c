#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <poll.h>
int main()
{
    int sfd[3];
    //First three for platform, next three for directional points
    for (int i = 0; i < 3; i++)
    {
        sfd[i] = socket(AF_INET, SOCK_STREAM, 0); // 0 given for default
        struct sockaddr_in serveaddr;
        serveaddr.sin_family = AF_INET;
            serveaddr.sin_port = htons(7080+i);
        serveaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        bind(sfd[i], (struct sockaddr *)&serveaddr, sizeof(serveaddr));
        listen(sfd[i], 5); // 5 is the wait no
    }
    int nsfd[3];
    for(int i=0;i<3;i++)
    {
    struct sockaddr_in clientaddr;
          int clientsize;
       nsfd[i] = accept(sfd[i], (struct sockaddr *)&clientaddr, &clientsize);
          if(nsfd[i]<0) {
           perror("nsfd error");
          }
    }
    while(1)
    {
     for(int i=0;i<3;i++)
     {
      char *str="adver";
      send(nsfd[i],str,strlen(str),0);
     }
    }
}
