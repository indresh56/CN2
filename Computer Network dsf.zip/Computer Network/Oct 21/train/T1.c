#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
//#include<pcap.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include <poll.h>
int main()
{
 int sfd = socket(AF_INET, SOCK_STREAM, 0); // 0 given for default
    struct sockaddr_in serveaddr;
    serveaddr.sin_family = AF_INET;
    serveaddr.sin_port = htons(7070); // change port no for different processes
    serveaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        if(connect(sfd, (struct sockaddr *)&serveaddr, sizeof(serveaddr))<0){
        perror("connect");
        exit(1);
    }
    char buff[256];
    if(recv(sfd,buff,sizeof(buff),0)<0){
     perror("recv1");
    }
    printf("%s\n",buff);
    memset(buff,0,256);
    char * buff2="Train came";
    if(send(sfd,buff2,strlen(buff2),0)<0){
    perror("send1");
    }
    char *buff3="Train left";
    if(send(sfd,buff3,strlen(buff3),0)<0){
    perror("send2");
    }
    
}
