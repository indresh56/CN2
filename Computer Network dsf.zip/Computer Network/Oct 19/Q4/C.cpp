#include <bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    cin >> s;
    s += " Modified by C";
    cout << s;
}
