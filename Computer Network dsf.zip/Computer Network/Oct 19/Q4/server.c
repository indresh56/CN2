#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <poll.h>
#include <sys/select.h>

int main()
{
    int sfd[3];
    for (int i = 0; i < 3; i++)
    {
        sfd[i] = socket(AF_INET, SOCK_STREAM, 0); // 0 given for default
        struct sockaddr_in serveaddr;
        serveaddr.sin_family = AF_INET;
        if (i == 0)
            serveaddr.sin_port = htons(7070);
        else if (i == 1)
            serveaddr.sin_port = htons(8080);
        else
            serveaddr.sin_port = htons(9090);
        serveaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        bind(sfd[i], (struct sockaddr *)&serveaddr, sizeof(serveaddr));
        listen(sfd[i], 5); // 5 is the wait no
    }

    while (1)
    {
        fd_set readfds;
        FD_ZERO(&readfds);
        int max_fd = -1;

        
        for (int i = 0; i < 3; i++) {
            FD_SET(sfd[i], &readfds);
            if (sfd[i] > max_fd) {
                max_fd = sfd[i];
            }
        }

        
        /*struct timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;*/

      
        int activity = select(max_fd + 1, &readfds, NULL, NULL, NULL);
        if (activity > 0)
        {
            for (int i = 0; i < 3; i++)
            {
                if (FD_ISSET(sfd[i],&readfds))
                {
                    struct sockaddr_in clientaddr;
                    int clientsize;
                    int nsfd = accept(sfd[i], (struct sockaddr *)&clientaddr, &clientsize);
                    int c = fork();
                    if (c > 0)
                        close(nsfd);
                    else
                    {
                        close(sfd[i]);
                        dup2(nsfd, 0);
                        dup2(nsfd, 1);
                        if (i == 0)
                            execl("./A", "A", NULL);
                        else if (i == 1)
                            execl("./B", "B", NULL);
                        else
                            execl("./C", "C", NULL);

                        return 0;
                    }
                }
            }
        }
    }
}

