#include <bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    cin >> s;
    s += " Modified by B";
    cout << s;
}