#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include <sys/sem.h>
#include<poll.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include<bits/stdc++.h>

int main()
{
socklen_t saddr_size; 
int data_size;
	struct sockaddr_in saddr;
	struct in_addr in;
	
	unsigned char *buffer = (unsigned char *)malloc(65536); //Its Big!
	
	printf("Starting...\n");
	
	sock_raw = socket(AF_INET , SOCK_RAW , 109);
	if(sock_raw < 0)
	{
		printf("Socket Error\n");
		return 1;
	}
	
	
    int sfd = socket(AF_INET, SOCK_STREAM, 0); // 0 given for default
    struct sockaddr_in serveaddr, clientaddr;
    serveaddr.sin_family = AF_INET;
    serveaddr.sin_port = htons(8080);
    serveaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    bind(sfd, (struct sockaddr *)&serveaddr, sizeof(serveaddr));
    listen(sfd, 5); // 5 is the wait no
    int clientsize;

    struct pollfd PFD[2];
    PFD[0].fd=sfd;
    PFD[1].fd=sock_raw;
    PFD[0].events=POLLIN;
    PFD[1].events=POLLIN;
	
	
	while(1)
	{
	 int a=poll(PFD,2,-1);
	 if(a>0)
	 {
	   for(int i=0;i<2;i++)
	   {
	       if(PFD[i].revents&POLLIN)
	       {
 		if(i==1)
 		{
		saddr_size = sizeof saddr;

		data_size = recvfrom(sock_raw , buffer , 65536 , 0 , (struct sockaddr*)&saddr , &saddr_size);
		if(data_size <0 )
		{
			printf("Recvfrom error , failed to get packets\n");
			return 1;
		}
		char *buff="Service 1";
	        sendto(sock_raw,buff,sizeof(buff),0,(struct sockaddr*)&saddr,saddr_size);
	        }
	        else{
	          int nsfd=accept(PFD[i].fd,(struct sockaddr *)&clientaddr,&clientsize);
	          int c=fork();
	          if(c>0) close(nsfd);
	          else{
	           close(PFD[i].fd);
	           char *str="Serviced by service 1";
	           send(nsfd,str,strlen(str),0);
	           
	          }
	        }
	        }
	     }
	   }
	        
	}
	close(sock_raw);
	printf("Finished");
	return 0;
}
