#include <stdio.h> 
#include <stdlib.h>
#include <sys/types.h> 
#include <unistd.h>

int main()
{
int c=0;
c=fork();
if(c==-1)
{

printf("Creation of child unsuccesful\n");
}
else
if(c>0)
{
printf("This is parent process\n");

}
else{
printf("This is child process\n");
}

}



//cc -o forkchild forkchild.c
//./forkchild
