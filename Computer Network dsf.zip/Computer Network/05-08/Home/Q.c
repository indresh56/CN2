#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include <stdlib.h>
void printline(int fd)
{

char c;
read(fd,&c,1);
while(c!='\n')
{
printf("%c",c);
read(fd,&c,1);
}

printf("\n");
}
int main()
{
int fd=open("in.txt",O_RDONLY);
printline(fd);
printline(fd);
sleep(2);
int ch=0;
ch=fork();
if(ch<=0)
{
printline(fd);
printline(fd);
printline(fd);
printline(fd);
printline(fd);
char fd_str[10];
snprintf(fd_str, sizeof(fd_str), "%d", fd);
//printf("%s",fd_str);
execl("./pexec","pexec",fd_str,NULL);
//int t=execl("./pexec","pexec",NULL);
//printf("%d",t);
}

}

