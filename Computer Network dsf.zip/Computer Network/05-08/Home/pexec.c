#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include <stdlib.h>
void printline(int fd)
{

char c;
read(fd,&c,1);
while(c!='\n')
{
printf("%c",c);
read(fd,&c,1);
}

printf("\n");
}
int main(int argc,char*argv[])
//int main()
{
//int fd=open("in.txt",O_RDONLY);
//printf("hello");
int fd = atoi(argv[1]);
printline(fd);
printline(fd);
printline(fd);

}

