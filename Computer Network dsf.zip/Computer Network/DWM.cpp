#include<bits/stdc++.h>
using namespace std;
void fun(string &s,int l,int i=0,string temp="")
{
if(i<s.size())
{
if(temp.size()<l) fun(s,l,i+1,temp+s[i]);
fun(s,l,i+1,temp);
}
else if(temp.size()==l) cout<<temp<<" ";
}
int main()
{
string s="abcdef";
for(int i=1;i<=s.size();i++)
{
fun(s,i);
cout<<endl;
}
}
