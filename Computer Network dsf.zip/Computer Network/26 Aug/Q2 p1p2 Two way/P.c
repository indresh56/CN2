#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

int main()
{

  int a=dup(0),b=dup(1);
  while(1)
  {
     char buff[100],buff2[100];
  scanf("%s",buff);
  }
}
