#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include<string.h>

int main()
{

char buff[100],buff2[100];
  scanf("%s",buff);
  printf("%d",strlen(buff));
}
