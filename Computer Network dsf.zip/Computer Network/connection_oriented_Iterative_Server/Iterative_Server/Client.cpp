#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
using namespace std;

#define MAXBUFSIZE 1024
#define PORTNO 5555

int main() {
    int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    if (sfd<0) {
        perror("socket error");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in srvaddr;
    srvaddr.sin_family=AF_INET;
    inet_pton(AF_INET,"192.168.193.165",&srvaddr.sin_addr.s_addr);
    srvaddr.sin_port=htons(PORTNO);

    if (connect(sfd,(struct sockaddr *)&srvaddr,sizeof(srvaddr))<0) {
        perror("connection failed");
        exit(EXIT_FAILURE);
    }

    while (1) {
        char buf[MAXBUFSIZE]; //="hello world\n";
        cout<<"Send Data: ";
        fgets(buf,MAXBUFSIZE,stdin);
        send(sfd,buf,strlen(buf)+1,0);
        if (buf[0]=='#') break;

        int rcv_size=recv(sfd,buf,MAXBUFSIZE,0);
        cout<<"received data: "<<buf<<endl;
    }
    
    return 0;
}
