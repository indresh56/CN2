#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
using namespace std;

#define MAXBUFSIZE 1024
#define PORTNO 5555

int main() {
    int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    if (sfd<0) {
        perror("socket_failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in addr;
    addr.sin_family=AF_INET;
    //addr.sin_addr.s_addr=INADDR_ANY;
    inet_pton(AF_INET,"127.0.0.1",&addr.sin_addr.s_addr);
    addr.sin_port=htons(PORTNO);

    if (bind(sfd,(struct sockaddr *)&addr,sizeof(addr))<0) {
        //if error frequently then use setsockopt()
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(sfd,3)<0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    while (1) {
        struct sockaddr_in clnaddr;
        socklen_t clnaddr_size=0;
        int nsfd=accept(sfd,(struct sockaddr *)&clnaddr,&clnaddr_size);

        bool flag=false;
        while (1) {
            char buf[MAXBUFSIZE];
            int rcv_size=recv(nsfd,buf,MAXBUFSIZE,0);
            cout<<"received data: "<<buf<<endl; 
            if (buf[1]=='#') flag=true; //## to terminate server
            if (buf[0]=='#') break; //# to end client

            strcpy(buf,"data received by server\n\0");
            send(nsfd,buf,strlen(buf)+1,0);
        }
        
        close(nsfd);

        if (flag) break;
    }

    close(sfd);

    return 0;
}