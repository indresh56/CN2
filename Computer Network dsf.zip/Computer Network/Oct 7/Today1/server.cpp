#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include <sys/sem.h>
#include<poll.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include<bits/stdc++.h>
using namespace std;

#define BUF_LEN 65536

int main() {
    int rsfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (rsfd == -1) {
        perror("socket");
        return 1;
    }

    int optval = 1;
    if (setsockopt(rsfd, IPPROTO_IP, SO_BROADCAST, &optval, sizeof(int)) < 0) {
        perror("setsockopt");
        close(rsfd);
        return 1;
    }
    
    struct sockaddr_in client;
    client.sin_family = AF_INET;
    client.sin_port = htons(12345); // Set the port number
    client.sin_addr.s_addr = inet_addr("127.0.0.1"); // Use the loopback address

    char buff[] = "hello";	
    unsigned int client_len = sizeof(client);
    cout << "Sending..." << endl;

    if (sendto(rsfd, buff, strlen(buff) + 1, 0, (struct sockaddr*)&client, client_len) < 0) {
        perror("send");
        close(rsfd);
        return 1;
    }

    close(rsfd); // Clean up
    return 0;
}
/*	int rsfd=socket(AF_INET,SOCK_RAW,IPPROTO_UDP);
	perror("socket");
	int optval=1;
	setsockopt(rsfd, IPPROTO_IP, SO_BROADCAST, &optval, 		   sizeof(int));//IP_HDRINCL
	cout<<"opt"<<endl;
		struct sockaddr_in client;
	client.sin_family=AF_INET;
	client.sin_addr.s_addr=inet_addr("127.0.0.1");

		char buff[]="hello";	
	client.sin_addr.s_addr=INADDR_ANY;

	unsigned int client_len=sizeof(client);
	cout<<"sending"<<endl;
  if(sendto(rsfd,buff,strlen(buff)+1,0,(struct sockaddr*)&client,sizeof(client))<0)
  perror("send");*/

