#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include <sys/sem.h>
#include<poll.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include<bits/stdc++.h>
using namespace std;
struct myipheader
 {
#if __BYTE_ORDER == __LITTLE_ENDIAN
    unsigned int ihl:4;
    unsigned int version:4;
#elif __BYTE_ORDER == __BIG_ENDIAN
    unsigned int version:4;
    unsigned int ihl:4;
#else
# error	"Please fix <bits/endian.h>"
#endif
    uint8_t tos;
    uint16_t tot_len;
    uint16_t id;
    uint16_t frag_off;
    uint8_t ttl;
    uint8_t protocol;
    uint16_t check;
    uint32_t saddr;
    uint32_t daddr;
    /*The options start here. */
 };
 
#define BUF_LEN 65536

int main() {
    int rsfd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (rsfd == -1) {
        perror("socket");
        return 1;
    }

  /*  int optval = 1;
    if (setsockopt(rsfd, IPPROTO_IP, SO_BROADCAST, &optval, sizeof(int)) < 0) {
        perror("setsockopt");
        close(rsfd);
        return 1;
    }*/
    
    struct sockaddr_in client;
    client.sin_family = AF_INET;
    client.sin_port = htons(12345); // Set the port number
    client.sin_addr.s_addr = inet_addr("127.0.0.1"); // Use the loopback address
struct myipheader *ip;
        char   buffer[65536];

        memset(buffer,'\0',sizeof(buffer));
        ip=(struct myipheader*)buffer;
        ip->version=4;
        ip->ttl=64;
        ip->id=0;
        ip->ihl=5;
        ip->protocol=100;	// value same as last argument(integer) of raw socket creation sys_call
        ip->saddr=inet_addr("1.2.3.4");
        ip->daddr=inet_addr("127.0.0.1");

        printf("Msg:");
        scanf("%s",buffer+60);
               // ip->tot_len=1000;
        const int payload_length = strlen(buffer + 60); // Get length of user input
ip->tot_len = htons(sizeof(struct myipheader) + payload_length); // Total length in network byte order

        if(sendto(rsfd,buffer,ntohs(ip->tot_len),0,(struct sockaddr*)&client,sizeof(client))<0)
        {
            perror("sendto");
            exit(1);
        }

    close(rsfd); // Clean up
    return 0;
}
