#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include <sys/sem.h>
#include<poll.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include<bits/stdc++.h>

using namespace std;

#define BUF_LEN 65536
int main()
{

    int rsfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (rsfd == -1) {
        perror("socket");
        return 1; // Exit if socket creation fails
    }

    char buf[BUF_LEN];
    struct sockaddr_in client;
    socklen_t clilen = sizeof(client);
    cout << "Waiting to receive..." << endl;

    if (recvfrom(rsfd, buf, BUF_LEN, 0, (sockaddr*)&client, &clilen) < 0)   {   
        perror("recv");
        close(rsfd); // Close socket on error
        return 1;
    }

    struct iphdr *ip = (struct iphdr*)buf;
    cout << "Received packet from: " << inet_ntoa(client.sin_addr) << endl;
    cout << (buf + (ip->ihl * 4)) << endl; // Assuming the data follows the IP header
    close(rsfd); // Clean up
    return 0;
}
/*int main()
{
	
	int rsfd=socket(AF_INET,SOCK_RAW,IPPROTO_UDP);
	if(rsfd==-1) perror("socket");
		char buf[BUF_LEN];
	struct sockaddr_in client;
	socklen_t clilen=sizeof(client);
	cout<<"receive"<<endl;
	if(recvfrom(rsfd,buf,BUF_LEN,0,(sockaddr*)&client,(socklen_t*)clilen)<0)
	perror("recv");
	 struct iphdr *ip;
  ip=(struct iphdr*)buf;
	cout<<(buf+(ip->ihl)*4)<<endl;
}*/
