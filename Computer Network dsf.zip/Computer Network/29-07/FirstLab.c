#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{
//printf("Hello %d\n",1);
//int n;
//scanf("%d",&n);
//printf("%d\n",n);


//Write
//int fd=open("in.txt",O_WRONLY|O_CREAT|O_TRUNC,0644);
int fd=open("in.txt",O_WRONLY|O_CREAT|O_APPEND,0644);
printf("%d",fd);
write(fd,"hello geeks\n",strlen("hello geeks\n"));

fd=open("in.txt",O_RDONLY|O_CREAT);
printf("%d\n",fd);


//Read

char*c=(char*)calloc(100,sizeof(char));
fd=open("in.txt",O_RDONLY);
int sz=read(fd,c,12);
printf("Read completed: %s\n",c);

close(fd);


/*FILE *fp=fopen("in.txt","w");
fprintf(fp,"%s %s %s %d","We","are","in",2024);


fp=fopen("in.txt","r");
if(fp==NULL){
printf("File not opened");
exit(0);
}
char buff[100];
while(fscanf(fp,"%s",buff)==1) printf("%s\n",buff);

fclose(fp);*/
}          
